import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { UsersComponent } from './components/users/users.component';
import { HeaderComponent } from './shared/header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { MatBadge, MatButtonModule, MatFormFieldModule, MatIconModule, MatToolbarModule,MatListModule, MatBadgeModule,MatCardModule} from '@angular/material';
import { SidenavComponent } from './shared/sidenav/sidenav.component';
import { HttpClientModule } from "@angular/common/http";
import { UserService } from '../app/services/user-list/user.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    UsersComponent,
    HeaderComponent,
    SidenavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatBadgeModule,
    MatListModule,
    MatBadgeModule,
    MatCardModule,
    HttpClientModule
  ],
  bootstrap: [AppComponent],
  providers: [
    { provide: 'apiUrl', useValue: 'https://reqres.in/api' }
  ]
})
export class AppModule { }
